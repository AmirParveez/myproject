namespace api.Models
{
    public class StudentModel
    {
        public string StudentName { get; set; } = "";
        public string PhoneNo { get; set; } = "";
    }
}
